# 基于STM32的角度跟随舵机云台:tada:
  (应该把所有文件放在一个文件夹里......)  
实现舵机跟随MPU6050的角度变换运动(无PID调节)   
## 硬件设备：   
     STM32F103、Oled、舵机SG90、mpu6050 
           
实现效果连接：  
https://www.bilibili.com/video/BV1S7411m7eu#reply4428566260

## 声明: 
部分库来自野火官方、STM32官方  
部分源自网络：http://www.51hei.com/bbs/dpj-166265-1.html  
         
