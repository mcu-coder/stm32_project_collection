void getjd_init(void);
void get_jd(void);
