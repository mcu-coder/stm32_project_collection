#ifndef __INTERFACE_H
#define __INTERFACE_H

void FirstUI(void);

#endif //__INTERFACE_H
