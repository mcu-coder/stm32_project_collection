# PDD
 基于STM32的倒车雷达项目--OLED显示，HC-SR04
## 设备 
> * STM32F103C8T6
> * 0.96寸 四脚OLED
> * HC-SR04超声波模块 
> * 按钮产生中断
## 使用到的库 
> * SSD1306 
> * DWT-Delay 
## 总结 
一个简单的项目,为了完成一个小任务而做,托管到Github为大家STM32驱动OLED和HC-SR04提供一点点入门帮助. 
