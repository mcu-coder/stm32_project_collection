# SlamRobot
 一款基于STM32的SLAM机器人移动底盘，可运行于ROS平台。
 详细说明移步我的博客 https://blog.csdn.net/qq_37416258/article/details/88358603
