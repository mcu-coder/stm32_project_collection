#ifndef __CCD_H
#define __CCD_H

#include "stm32f10x.h"

u8 LV4CCD_Init(void);
#endif
