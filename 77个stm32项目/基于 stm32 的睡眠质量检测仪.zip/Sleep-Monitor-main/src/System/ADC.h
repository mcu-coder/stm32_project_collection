#ifndef __ADC_H
#define __ADC_H

void AD_Init(void);
uint16_t AD_GetValue(void);


#endif
