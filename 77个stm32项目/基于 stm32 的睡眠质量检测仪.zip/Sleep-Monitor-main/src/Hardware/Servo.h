#ifndef __SERVO_H_
#define __SERVO_H_

void Servo_Init_(void);
void Servo_SetAngle(float Angle);

#endif
