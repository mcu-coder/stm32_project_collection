﻿# Sleep-Monitor —— 基于 stm32 的睡眠质量& 环境检测仪
 
![1](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/06e9547c-ad06-4274-bad5-fe46553ad3a6)
![2](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/5586d7d7-2842-4ee5-a004-eef90a222e8f)
![3](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/5ada3b6d-def1-4123-ba2e-08b2dab025cc)
![4](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/c12e83c9-30f3-4fea-9bb8-e31e450e7de8)
![5](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/dec41f81-018c-409d-bb66-57ee630cb75a)
![6](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/6c17076d-0ceb-498e-ae6b-134027fb3622)
![7](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/d87939b9-4a90-42da-b59f-0e073547e70e)
![8](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/7d7d7678-44a4-4232-8459-230d73a6a372)
![9](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/8ad97dfd-3eb3-4e35-ac44-ee7449048fad)
![10](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/4a6b67b5-bfb9-4f77-988b-8376c21f0977)
![11](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/fb959781-f353-483e-b498-cad842fd5ed8)
![12](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/542510f5-451d-49fd-b4dd-ab5a727dc69e)
![13](https://github.com/aystmjz/Sleep-Monitor/assets/85049845/40c94352-bfa5-43b2-aae0-24c0f896c57a)

