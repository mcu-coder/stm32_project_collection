#ifndef _ZIMO_ST9_H_
#define _ZIMO_ST9_H_
extern const unsigned char zm_a_z_st9_8_12[312];
extern const unsigned char zm_A_Z_st9_8_12[312];
extern const unsigned char zm_0_9_st9_8_12[120];
extern const unsigned char zm_sign_st9_8_12[24];
extern const unsigned char zm_sign_space_st9_8_12[12];
extern const unsigned char zm_sign_colon_st9_8_12[12];
extern volatile unsigned char *p_zm_ascii_st9[128];
extern volatile unsigned char p_zm_step_st9[128];

#endif

