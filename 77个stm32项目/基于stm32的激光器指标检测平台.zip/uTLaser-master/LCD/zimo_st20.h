#ifndef _ZIMO_ST20_H_
#define _ZIMO_ST20_H_

#define ZM_ST20_W 16 //��ģ����
#define ZM_ST20_H 27 //��ģ�߶�
extern unsigned char *p_zm_ascii_st20[128];
extern unsigned char p_zm_step_st20[128];

#endif

