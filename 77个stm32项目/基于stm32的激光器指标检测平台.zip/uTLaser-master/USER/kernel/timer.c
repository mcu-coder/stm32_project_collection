#include "timer.h"

struct tm_task sg_tt[16];


void tm_init()
{

}
void tm_tick()
{

}

void tm_add(struct tm_task *tt)
{

}

void tm_del(struct tm_task *tt)
{

}