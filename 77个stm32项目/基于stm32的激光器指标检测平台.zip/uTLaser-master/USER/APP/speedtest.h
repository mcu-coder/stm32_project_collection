#ifndef _SPEED_TEST_H_
#define _SPEED_TEST_H_

void TestTickReset();
int TestGetTick();
int TestTick();
void Test_LCD_L0_DrawBitmap_1BPP();
void Test_LCD_L0_DrawBitmap_2BPP();
#endif