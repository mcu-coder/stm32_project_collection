/*
 * Automatically generated C config: don't edit
 * Project "Hello-KuGo_Menglong" Configuration
 * Depand on config.mk
 */
#ifndef _AUTO_CONFIG_H_
#define _AUTO_CONFIG_H_

#define CONFIG_PROJ                                             1
#define CONFIG_Afjlw                                            1
#define CONFIG_jLLWL                                            c
#define CONFIG_JJLKW                                            23
#define CONFIG_wmenglonww                                       "kjlww"
#define CONFIG_dandshi                                          1
#define CONFIG_FS_YAFFS2                                        1
#define CONFIG_FS_YAFFS                                         1
#define CONFIG_FS_YAFFS3                                        1
#define CONFIG_s                                                2
#define CONFIG_s                                                3
#define CONFIG_s                                                12

#endif
