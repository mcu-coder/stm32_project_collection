/**
* @mainpage 
* @author MenglongWu
* @date 2014-07-02
* @section Product
 - uLaser 光器件测试平台:
  -  todo

* @section notes Version
- V1.0.0-bate
  简单的调试界面
  - 电源开关
  - APD电压切换
  - PWM通道选择
  - PWM反转
  - PWM脉宽选择
  - 连续光功率选择

- V1.0.1-bate
  - 去除PWM反转
  - LCD触屏校准界面
  - LCD触屏精度测试界面
  - 仿WP界面桌面
  - 弥补防WP界面不能滑动的缺陷，添加两个桌面移动按钮

- V1.0.2-bate
  - 关键：优化SSD1963在ucgui的驱动层（但存在一些bug，不过不影响，后期继续维护）
  - 添加小黄人动态Logo
