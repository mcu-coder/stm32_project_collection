#ifndef _TIM_H_
#define _TIM_H_

void Timer1Init(void);//电机
void Timer5Init(void);//霍尔	

void Timer8Init(void);//电机
void Timer2Init(void);//霍尔

#endif
