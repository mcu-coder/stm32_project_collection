#ifndef __CLOCK_H
#define __CLOCK_H

#include "config.h"

#define PI 3.1415926 

void ShowClock(void);  //��ʾʱ��

#endif

