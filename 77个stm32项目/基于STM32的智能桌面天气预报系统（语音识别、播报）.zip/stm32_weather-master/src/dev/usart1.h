#ifndef __USART1_H
#define __USART1_H

#include "config.h"

void USART1_Init(uint32 bound);

#endif

