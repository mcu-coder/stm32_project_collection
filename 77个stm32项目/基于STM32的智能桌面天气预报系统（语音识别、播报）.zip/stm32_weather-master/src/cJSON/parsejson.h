#ifndef __PARSEJSON_
#define __PARSEJSON_

#include "sys.h"

u8 parse_3days_weather(void);
u8 parse_now_weather(void);

#endif



