#ifndef __PRINTER_H
#define __PRINTER_H

#include "stm32f10x.h"


void Print_Queue_Info(void);
#endif
