#ifndef __BUZZER_H
#define __BUZZER_H

void Beep_Init(void);
void Beep_ON(void);
void Beep_OFF(void);
void Beep_Turn(void);

#endif
