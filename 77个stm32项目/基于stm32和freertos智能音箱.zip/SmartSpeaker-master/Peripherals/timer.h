#ifndef __TIMER_H
#define	__TIMER_H

#include "stm32f4xx.h"


void vTimer2_Init(void);
void Delay_us(uint32_t uscnt);


#endif /* __TIMER_H */
