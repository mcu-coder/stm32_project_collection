# adxl345_driver_for_stm32
adxl345三轴加速度传感器适用于STM32的固件库的驱动


## 说明
目前仅支持读取xyz坐标
