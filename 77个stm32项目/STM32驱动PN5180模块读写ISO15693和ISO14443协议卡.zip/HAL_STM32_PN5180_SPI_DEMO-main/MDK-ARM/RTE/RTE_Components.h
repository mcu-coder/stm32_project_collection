
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'HAL_STM32_PN5180_SPI_DEMO' 
 * Target:  'HAL_STM32_PN5180_SPI_DEMO' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f10x.h"


#endif /* RTE_COMPONENTS_H */
