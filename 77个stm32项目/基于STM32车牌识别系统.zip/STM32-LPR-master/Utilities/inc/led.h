  
/* ��ֹ�ݹ������ͷ�ļ� ------------------------------------------------------*/

#ifndef __LED_H
#define __LED_H

#ifdef __cplusplus
 extern "C" {
#endif 

/* Includes ------------------------------------------------------------------*/
	 
void Led_init(void);	//��ʼ�� LED
	 
#ifdef __cplusplus
}
#endif


#endif 