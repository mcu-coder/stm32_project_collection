#ifndef __CHSENSOR_H
#define __CHSENSOR_H

void CHsensor_Init(void);
uint16_t gethumidnes(void);

#endif
