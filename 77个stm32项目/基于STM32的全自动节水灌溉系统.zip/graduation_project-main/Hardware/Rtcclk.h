#ifndef __RTCCLK_H
#define __RTCCLK_H
    
void Rtcclk_Init(void);

#endif
