#ifndef __FLOWSENSOR_H
#define __FLOWSENSOR_H

void Flowsensor_Init(void);

#endif
