#ifndef __SETTIME_H
#define __SETTIME_H

void setnowtime(timer* time,Control* Controlsignal);
void settime(timer* time,Control* Controlsignal);
void setliang(uint32_t* lia,Control* Controlsignal);

#endif
