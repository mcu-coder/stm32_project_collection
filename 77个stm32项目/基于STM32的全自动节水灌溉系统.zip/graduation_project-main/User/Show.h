#ifndef __SHOW_H
#define __SHOW_H
    
void showdata(timer* time,Control* Controlsignal,uint32_t* setliang,uint32_t* lia);
void showsetdata(timer time,Control Controlsignal,uint32_t setliang,uint32_t lia);
void show(timer time,uint32_t liacount,uint8_t pop,uint16_t humidnes);

#endif
