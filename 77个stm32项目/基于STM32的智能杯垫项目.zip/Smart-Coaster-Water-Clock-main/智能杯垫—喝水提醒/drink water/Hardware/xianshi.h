#ifndef __XIANSHI_H
#define __XIANSHI_H

void OLED_WATCH(float Mark);
void Sound_Sensor(uint16_t Seconds);
#endif
