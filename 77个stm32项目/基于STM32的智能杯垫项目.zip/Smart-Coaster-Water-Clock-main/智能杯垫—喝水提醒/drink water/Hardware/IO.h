#ifndef __IO_H
#define __IO_H

void IO_Init(void);

#endif
