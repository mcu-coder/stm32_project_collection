#ifndef __THRESHOLD_H
#define __THRESHOLD_H

void TIM4IT_Init(void);
void TIM4IT_DeInit(void);
void Threshold_PPM(void);
void Threshold_Lux(void);
void Threshold_Wind(void);
void Threshold_Rain(void);

#endif


