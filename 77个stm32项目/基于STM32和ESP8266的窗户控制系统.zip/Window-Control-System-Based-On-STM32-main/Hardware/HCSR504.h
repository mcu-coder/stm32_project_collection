#ifndef __HCSR504_H
#define __HCSR504_H
#include "stm32f10x.h"                  // Device header

void HCSR504_Init(void);
void HCSR504_DeInit(void);
#endif

