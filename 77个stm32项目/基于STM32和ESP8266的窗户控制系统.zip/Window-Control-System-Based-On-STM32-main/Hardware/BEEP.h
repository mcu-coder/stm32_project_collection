#ifndef __BEEP_H
#define __BEEP_H

void BEEP_Turn(void);
void Beep_Init(void);
void BEEP_ON(void);
void BEEP_OFF(void);
#endif

