#ifndef __LUX_H
#define __LUX_H
#include "stm32f10x.h"                  // Device header

float Get_Lux(void);

#endif


