基于STM32的窗户控制系统

1．通过无线通信模块在传统窗户上搭建传感器局域网；

2．通过对温湿度的检测，采集到室内外温湿度等数据；

3．通过非法入侵的检测，发出驱离警告；

4．通过雨滴、风力检测和光强度检测室外天气状况；

5．通过一定的算法控制电机驱动模块实现自动开关窗；

6．通过无线通信模块实现手机APP远程查看及控制开关窗。


使用请烧录固件
https://github.com/Senpouuu/8266-AT--onenet-mqtt
![Schematic_窗户控制系统 copy_2023-07-14](https://github.com/Senpouuu/Window-Control-System-Based-On-STM32/assets/102023293/ff3fd174-2eda-45fe-a6a9-8dea54e6df44)
