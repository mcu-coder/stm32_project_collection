#ifndef __SR04__
#define __SR04__

#include "sys.h"

 //��������
void UltrasonicWave_Configuration(void);
void UltrasonicWave_StartMeasure(void);

#define Trig PCout(1)		//PC1	TRIG


#endif

