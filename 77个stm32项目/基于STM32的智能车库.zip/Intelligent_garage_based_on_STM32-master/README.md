# Intelligent_garage_based_on_STM32
基于STM32的智能车库
实现功能：刷卡自动停车（步进电机）、拍照、停车路径规划、自动分配停车位、时长收费等
