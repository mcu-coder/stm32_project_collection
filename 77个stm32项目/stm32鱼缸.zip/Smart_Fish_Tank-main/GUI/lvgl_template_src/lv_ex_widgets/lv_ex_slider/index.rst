C
^

Slider with custom style
"""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_slider/lv_ex_slider_1
  :language: c

Set value with slider 
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_slider/lv_ex_slider_2
  :language: c


MicroPython
^^^^^^^^^^^

No examples yet.
