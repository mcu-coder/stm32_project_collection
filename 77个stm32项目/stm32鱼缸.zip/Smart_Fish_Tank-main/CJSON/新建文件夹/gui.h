#ifndef __GUI_H
#define __GUI_H

void showRTweather(void);
void showRDweather(void);
void refresh(void);
void switchWeather(void);
void gui_load(void);

#endif

