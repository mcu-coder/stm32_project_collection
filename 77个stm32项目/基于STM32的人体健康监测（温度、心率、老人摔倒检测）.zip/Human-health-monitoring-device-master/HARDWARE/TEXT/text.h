#ifndef _TEXT_H
#define _TEXT_H


#include "sys.h"

void Show_Chinese(u8 x,u16 y,u8 *font);



void xianshi(void);









#endif

