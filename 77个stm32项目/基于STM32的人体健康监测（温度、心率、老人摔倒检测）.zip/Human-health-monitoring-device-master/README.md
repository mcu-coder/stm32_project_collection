# Human-health-monitoring-device-
基于STM32的人体健康监测装置

检测当前的温度与心率，同时通过MPU6050检测老人是否摔倒

将摔倒信息发送给子女
