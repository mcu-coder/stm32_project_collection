#ifndef __TIMER_H__
#define __TIMER_H__

void Timer_Init();	

#endif
