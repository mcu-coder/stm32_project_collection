#ifndef __VOICE_H__
#define __VOICE_H__

void Voice_Init(void);
uint8_t Voice_GetRxData(void);	

#endif
