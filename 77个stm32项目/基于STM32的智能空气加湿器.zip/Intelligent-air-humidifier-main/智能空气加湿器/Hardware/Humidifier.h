#ifndef __HUMIDIFIER_H__
#define __HUMIDIFIER_H__


void Humi_Init();
void Humi_ON();
void Humi_OFF();	

#endif
