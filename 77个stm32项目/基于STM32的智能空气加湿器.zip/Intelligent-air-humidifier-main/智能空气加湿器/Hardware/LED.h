#ifndef __LED_H__
#define __LED_H__

void LED_Init();	
void LED1_ON();
void LED1_OFF();
void LED2_ON();
void LED2_OFF();
void LED1_Turn();
void LED2_Turn();	
	
#endif
