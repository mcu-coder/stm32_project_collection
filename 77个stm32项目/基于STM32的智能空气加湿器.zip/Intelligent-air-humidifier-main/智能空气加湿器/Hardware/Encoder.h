#ifndef __ENCODER_H__
#define __ENCODER_H__

void Encoder_Init();
int16_t Encoder_Get();

#endif