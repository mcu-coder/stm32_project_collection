#ifndef __AD_H__
#define __AD_H__

void AD_Init(void);
uint16_t AD_Getvalue(void);	

#endif
