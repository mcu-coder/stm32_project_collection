#ifndef __PWM_H__
#define __PWM_H__

void PWM_Init();
void PWM_SetCompare2(uint16_t Compare);


#endif
