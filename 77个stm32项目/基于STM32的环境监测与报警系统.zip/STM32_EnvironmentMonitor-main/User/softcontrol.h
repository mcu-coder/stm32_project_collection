#include "system.h"
#include "usart.h"
int flag1=0;
int flag2=0;
int flag3=0;
int flag4=0;

