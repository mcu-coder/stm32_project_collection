#ifndef _GPIO_H
#define _GPIO_H
#include "stm32f10x_rcc.h"
#include "SysTick.h"
void initGPIO();
void Dht11_Pin_Mode(int a);
#endif