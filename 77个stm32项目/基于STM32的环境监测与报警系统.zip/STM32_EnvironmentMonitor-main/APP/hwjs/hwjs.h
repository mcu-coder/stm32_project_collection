#ifndef _hwjs_H
#define _hwjs_H

#include "system.h"



void Hwjs_Init(void);
u8 HW_jssj(void);

//����ȫ�ֱ���
extern u32 hw_jsm;
extern u8  hw_jsbz;
extern u8  frame_cnt;

#endif
