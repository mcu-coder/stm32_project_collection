#ifndef _exti_H
#define _exti_H


#include "system.h"

void My_EXTI_Init(void);

#endif
