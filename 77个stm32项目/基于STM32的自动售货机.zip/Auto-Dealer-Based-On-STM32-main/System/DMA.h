#ifndef __DMA_H
#define __DMA_H
#include "stm32f10x.h"                  // Device header

void DriectMemoryAccess_Init(void);
void DMA_Reset(void);

#endif
