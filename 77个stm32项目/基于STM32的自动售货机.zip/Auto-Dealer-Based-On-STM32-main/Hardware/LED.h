#ifndef __LED_H
#define __LED_H
void LED_Init(void);
void LED0_ON(void);
void LED1_ON(void);
void LED2_ON(void);
void LED3_ON(void);
void LED4_ON(void);
void LED5_ON(void);
void LED6_ON(void);
void LED7_ON(void);
void LED0_OFF(void);
void LED1_OFF(void);
void LED2_OFF(void);
void LED3_OFF(void);
void LED4_OFF(void);
void LED5_OFF(void);
void LED6_OFF(void);
void LED7_OFF(void);
void LED1_Turn(void);
void LED2_Turn(void);
void LED_APPSwitch(void);
void Mortor_Init(void);
void Mortor_Turn(void);

#endif


