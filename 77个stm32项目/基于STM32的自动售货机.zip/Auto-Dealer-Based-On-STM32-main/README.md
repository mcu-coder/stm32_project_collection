# Auto Dealer Based ON STM32
 基于STM32的自动售货机
