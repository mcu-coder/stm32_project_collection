# 服务器配置

![](peizhi.png)