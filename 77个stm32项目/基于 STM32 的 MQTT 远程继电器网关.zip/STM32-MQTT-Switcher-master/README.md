# STM32F103- mqtt-继电器开关源码

## 1.关于仓库

​        本仓库是实际项目下的一个MQTT协议继电器开关的源码，稳定可靠，适合快速移植到各种STM32MCU为主的开发板上，很适合快速开发。为了让大家少走弯路，特地将本公司的生产环境下的源码开源出来，供大家学习观摩。

## 2.开源规约

​        本仓库源码开源，允许任意开发，允许商业用途，但是不承担相关技术咨询和法律责任，如果需要技术咨询，请单独联系本人。

## 3.开源协议

本项目遵循Apache2协议。

## 4.作者

wwhai、xianli。

## 5.预览效果

[![GZ3uRK.md.jpg](https://s1.ax1x.com/2020/03/29/GZ3uRK.md.jpg)](https://imgchr.com/i/GZ3uRK)
[![GZ3mPx.md.png](https://s1.ax1x.com/2020/03/29/GZ3mPx.md.png)](https://imgchr.com/i/GZ3mPx)
[![GZ3VaR.md.png](https://s1.ax1x.com/2020/03/29/GZ3VaR.md.png)](https://imgchr.com/i/GZ3VaR)
[![GZ3kqJ.md.png](https://s1.ax1x.com/2020/03/29/GZ3kqJ.md.png)](https://imgchr.com/i/GZ3kqJ)
