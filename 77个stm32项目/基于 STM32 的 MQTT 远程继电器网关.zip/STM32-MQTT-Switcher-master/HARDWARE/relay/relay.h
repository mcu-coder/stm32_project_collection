/*
 * relay.h
 *
 *  Created on: 2017年5月16日
 *      Author: xianlee
 */

#ifndef __RELAY_H__
#define __RELAY_H__

void relay_init(void);

void relay_on(void);

void relay_off(void);

#endif /* _RELAY_H_ */
