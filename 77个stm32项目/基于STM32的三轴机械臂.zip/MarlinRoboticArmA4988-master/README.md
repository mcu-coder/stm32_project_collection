# MarlinRoboticArmA4988

#define motor1_step  PAOUT(10)

#define motor2_step  PAOUT(4)

#define motor3_step  PAOUT(5)


#define motor1_dir  PAOUT(0)

#define motor2_dir  PAOUT(1)

#define motor3_dir  PAOUT(9)


#define motor1_ms1  PBOUT(8)

#define motor2_ms1  PAOUT(7)

#define motor3_ms1  PBOUT(0)


#define motor1_ms2  PBOUT(1)

#define motor2_ms2  PBOUT(5)

#define motor3_ms2  PBOUT(9)


#define motor1_ms3  PBOUT(12)

#define motor2_ms3  PBOUT(13)

#define motor3_ms3  PBOUT(14)


#define motor1_en  PBOUT(15)

#define motor2_en  PBOUT(10)

#define motor3_en  PBOUT(11)

SLEEP和RES短接   VDD输入3.3V  VMOT12V
