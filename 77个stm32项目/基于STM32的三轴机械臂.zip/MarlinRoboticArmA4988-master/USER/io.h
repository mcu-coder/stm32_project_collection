#ifndef __IO_H
#define __IO_H
	
#include "bit.h" 
#include "stm32f10x.h"


void GPIOINIT(void );

#endif
