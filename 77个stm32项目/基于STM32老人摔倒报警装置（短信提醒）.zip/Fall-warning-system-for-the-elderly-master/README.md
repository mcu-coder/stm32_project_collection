# Fall-warning-system-for-the-elderly
老人摔倒报警装置

利用超声波模块检测老人离地距离，

利用GPS模块实时获取老人位置，

摔倒后发送短信给老人子女。
