#ifndef _HC_SR04_
#define _HC_SR04_

#include "sys.h"



extern float time ;

void hc_sr04_init(void);
float  Get_hcsr04length(void);







#endif


