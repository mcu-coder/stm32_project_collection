#ifndef _IWDOG_
#define	_IWDOG_
void IWDG_INIT(void);

#endif

