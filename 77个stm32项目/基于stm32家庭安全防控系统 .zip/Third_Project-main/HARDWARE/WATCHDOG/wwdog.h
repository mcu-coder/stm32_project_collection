#ifndef _WWDOG_
#define	_WWDOG_
void WWDG_INIT(void);
#endif

