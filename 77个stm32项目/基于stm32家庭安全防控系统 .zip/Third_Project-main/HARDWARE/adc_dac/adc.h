#ifndef __ADC_H
#define __ADC_H
#include "stm32f4xx.h"


void ADC1_IN6_Init(void);
void ADC_INIT(void);
void ADC_LIGHT_INIT(void);
#endif
