#ifndef _DAC_
#define _DAC_
void DAC1_OUT_Init(void);
#endif

