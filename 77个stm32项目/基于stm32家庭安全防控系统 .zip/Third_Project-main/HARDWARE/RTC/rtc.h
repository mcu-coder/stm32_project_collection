#ifndef _RTC_
#define	_RTC_
void RTC_INIT(void);
void ALARM_INIT(void);
#endif

