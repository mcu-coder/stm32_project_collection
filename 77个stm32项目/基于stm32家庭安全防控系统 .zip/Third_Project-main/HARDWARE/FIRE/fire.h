#ifndef _FIRE_
#define	_FIRE_
#include "stm32f4xx.h"
#include "sys.h"
#include "delay.h"
void Fire_Init(void);
void Fire_Detect(void);
#endif

