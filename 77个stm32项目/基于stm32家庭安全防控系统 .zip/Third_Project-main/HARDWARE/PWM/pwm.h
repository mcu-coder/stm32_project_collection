#ifndef PWM_H
#define PWM_H


#include "stm32f4xx.h"




void pwm0_init(void);

void pwm1_init(void);
void pwm2_init(void);


#endif


