#ifndef __UART_H
#define __UART_H

#include "stm32f4xx.h"
#include "sys.h"  
#include "stdio.h"                    //标准库

//函数声明
void Init_USART1(uint32_t baud);


#endif
