#ifndef __DELAY_H
#define __DELAY_H

#include "stm32f4xx.h"
#include "includes.h"
void delay_us(uint32_t nus); //΢�
void delay_ms(uint32_t nms); //���뼶

#endif
