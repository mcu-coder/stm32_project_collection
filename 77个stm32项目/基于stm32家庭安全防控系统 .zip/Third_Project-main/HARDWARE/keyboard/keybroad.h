#ifndef _KEYBROAD_
#define	_KEYBROAD_
#include "stm32f4xx.h"
#include "sys.h"
#include "delay.h"
#include "newprintf.h"
#include "stdio.h"
u8 Keybroad_Input(u8 mode);
void Keybroad_Config_Init(void);
#endif

