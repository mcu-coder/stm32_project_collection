# FYP_STM32
此项目是基于STM32对音频进行 AD采样后存储在SD中
