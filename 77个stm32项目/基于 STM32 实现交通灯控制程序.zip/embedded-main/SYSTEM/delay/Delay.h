#ifndef __DELAY_H
#define __ DELAY_H
void Delay(unsigned int count);
#endif
