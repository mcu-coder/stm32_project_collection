#include "Delay.h"
void Delay(unsigned int count)						  	//��ʱ����
{
	unsigned int i;
	for(;count!=0;count--)
	{
		i=100;
		while(i--);
	}	
}
