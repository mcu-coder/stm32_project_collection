# RFID-Reader

基于STM32的RFID读卡器程序.
支持常见的串口RFID读卡器，包括IC卡和ID卡.