package com.example.first_spring.entity;

public class allrescue {
    private int rescueall;
    private int rescueuse;
    private int  warnall;

    public int getRescueall() {
        return rescueall;
    }

    public void setRescueall(int rescueall) {
        this.rescueall = rescueall;
    }

    public int getRescueuse() {
        return rescueuse;
    }

    public void setRescueuse(int rescueuse) {
        this.rescueuse = rescueuse;
    }

    public int getWarnall() {
        return warnall;
    }

    public void setWarnall(int warnall) {
        this.warnall = warnall;
    }
}
