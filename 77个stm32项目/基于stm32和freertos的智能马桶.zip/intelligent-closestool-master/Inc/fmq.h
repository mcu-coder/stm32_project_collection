#ifndef FMQ_H
#define FMQ_H

#include "main.h"
#include "stdbool.h"

bool FMQ(void);


#endif
