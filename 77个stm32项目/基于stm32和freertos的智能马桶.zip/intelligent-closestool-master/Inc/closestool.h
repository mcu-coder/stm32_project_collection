#ifndef CLOSESTOOL_H
#define CLOSESTOOL_H

#include "main.h"

void Startclosestool(void const * argument);
void hotWaterLoop(void const * argument);                                                                         ;

#endif

