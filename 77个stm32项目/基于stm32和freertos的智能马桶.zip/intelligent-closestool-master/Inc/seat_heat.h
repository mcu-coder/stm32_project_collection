#ifndef SEAT_HEAT_H
#define SEAT_HEAT_H
#include "main.h"
#include "fmq.h"

void sitLoop(void const * argument);
void startIsSit(void const * argument);

#endif

