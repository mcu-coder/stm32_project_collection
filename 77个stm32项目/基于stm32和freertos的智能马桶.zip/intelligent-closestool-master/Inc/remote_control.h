/*
 * remote_control.h
 *
 *  Created on: 2019��7��24��
 *      Author: caiwe
 */

#ifndef REMOTE_CONTROL_H_
#define REMOTE_CONTROL_H_

void StartRemoteControl(void const * argument);

#endif /* REMOTE_CONTROL_H_ */
