#ifndef OS_TOOL_H
#define OS_TOOL_H

#include "main.h"
#include "cmsis_os.h"

void uOsWaitMessage(lastT,func,waitms) \
	do{	\
	
	
	}while(0)


#endif