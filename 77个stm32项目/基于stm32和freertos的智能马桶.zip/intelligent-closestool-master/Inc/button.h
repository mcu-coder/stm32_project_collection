#ifndef BUTTON_H
#define BUTTON_H

void buttonLoop(void const * argument);

#endif
