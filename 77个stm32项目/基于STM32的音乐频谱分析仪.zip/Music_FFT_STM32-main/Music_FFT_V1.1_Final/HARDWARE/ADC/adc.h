#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"
void FFT_RCC_Configuration(void);
void FFT_GPIO_Configuration(void);
void FFT_DMA_Init(void);
void FFT_ADC_Init(void);
void TIM2_Configuration(void);
void TIM2_NVIC_Configuration(void);


 
#endif 
