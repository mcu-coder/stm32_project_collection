#ifndef _OPENMV_USART_H
#define _OPENMV_USART_H

#include "sys.h" 

void Openmv_Usart_Init(u32 bound);

#endif

