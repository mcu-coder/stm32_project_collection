#ifndef  _FOLLOW_H
#define  _FOLLOW_H

#include "sys.h" 

#define TR1 PCin(3)
#define TR2 PCin(1)
#define TR3 PAin(11)
#define TR4 PBin(14)
#define TR5 PDin(2)
#define TR6 PCin(10)
#define TR7 PBin(15)
#define TR8 PCin(9)

void Follow_Init(void);

#endif

