#ifndef _BLUETOOTH_H
#define _BLUETOOTH_H

#include "sys.h" 

void Bluetooth_Init(u32 bound);

#endif

