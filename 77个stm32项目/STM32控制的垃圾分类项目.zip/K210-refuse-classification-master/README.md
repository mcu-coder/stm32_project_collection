# K210
一个使用百度paddle训练模型部署到K210再通过STM32控制的垃圾分类项目

paddle项目地址：https://aistudio.baidu.com/aistudio/projectdetail/3477303

使用开发板：亚博智能K210

           STM32F103ZET6
           
           
第一次使用github

2022.10.10

建议使用maixhub非常好用 效果也不错
