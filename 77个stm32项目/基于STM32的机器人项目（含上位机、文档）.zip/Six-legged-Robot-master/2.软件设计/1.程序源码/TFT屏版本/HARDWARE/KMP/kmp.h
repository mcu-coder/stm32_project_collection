#ifndef __KMP_H
#define __KMP_H	 
#include "sys.h"

void DataTransfer(char *dst_buf,u16 len);

#endif
