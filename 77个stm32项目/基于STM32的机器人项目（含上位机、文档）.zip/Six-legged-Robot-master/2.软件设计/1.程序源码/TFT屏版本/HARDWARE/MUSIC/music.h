#ifndef __MUSIC_H
#define __MUSIC_H	 
#include "sys.h"

//#define OPEN_VOICE PFout(10)// PF10


void MUSIC_Init(void);
void music_test(void);

#endif
