#ifndef __BLE_H
#define __BLE_H	 
#include "sys.h"
#define OPEN_BLE PBout(5)// PB5

void BLE_Init(void);
void ble_test(void);

#endif
