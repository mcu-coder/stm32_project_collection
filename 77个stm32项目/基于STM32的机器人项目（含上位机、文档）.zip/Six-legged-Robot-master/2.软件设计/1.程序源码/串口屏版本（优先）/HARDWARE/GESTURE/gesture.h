#ifndef __GESTURE_H
#define __GESTURE_H	 
#include "sys.h"
//#define OPEN_BLE PFout(9)// PF9 

void GESTURE_Init(void);
u8 gesture_test(void);

#endif
