#ifndef __KEY_H
#define __KEY_H

#include "sys.h"

void Key_Init(void);
void Key_Scan(void);
//void exit15_12_init();

#endif
