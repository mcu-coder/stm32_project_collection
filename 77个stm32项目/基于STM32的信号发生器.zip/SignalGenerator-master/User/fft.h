#ifndef _FFT_H
#define _FFT_H
#include "c.h"





#endif

