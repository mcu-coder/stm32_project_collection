#ifndef _PARAMANAGER_H
#define _PARAMANAGER_H
#include "c.h"


void InitParaManager(void);
void PM_SetValueFromArray(void);
void PM_SetArrayFromValue(void);

#endif

